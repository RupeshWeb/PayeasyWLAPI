﻿using BusinessEntities;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net;
using System.Text;

namespace BusinessServices.TransXT
{
    public class ClsTransXTCommunicator
    {
        private static string authToken = configuration.getValues("authToken");
        private static string userName = configuration.getValues("username");
        private static string password = configuration.getValues("password");
        private static string authUrl = configuration.getValues("authUrl");
        private static string secret = configuration.getValues("secret");
        private static string checksumURL = configuration.getValues("checkSumUrl");
        private static string updatedToken = "";

        private static string callSecuredService(Uri uri, string payload, string token)
        {
            string message;
            try
            {
                WebRequest request = WebRequest.Create(uri.AbsoluteUri);
                request.PreAuthenticate = true;
                request.Headers.Add("Authorization", "Bearer " + token);
                request.ContentType = "application/json";
                request.Method = "POST";
                byte[] bytes = Encoding.UTF8.GetBytes(payload);
                request.ContentLength = bytes.Length;
                //ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, (sender, certificate, chain, sslPolicyErrors) => true);
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, errors) => {return true;};
                Stream requestStream = request.GetRequestStream();
                using (requestStream = request.GetRequestStream())
                {
                    requestStream.Write(bytes, 0, bytes.Length);
                }
                WebResponse response = request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                if (responseStream == null)
                {
                    message = null;
                }
                else
                {
                    string str = new StreamReader(responseStream, Encoding.Default).ReadToEnd();
                    responseStream.Close();
                    response.Close();
                    message = str;
                }
            }
            catch (Exception exception1)
            {
                message = exception1.Message;
                ClsMethods.ResponseLogs(1, "callSecuredService", "MobileWare", uri.AbsoluteUri, payload + " | token: " + token, message, 0, "", "");
            }
            return message;
        }

        private static string callService(TransXTReq request, string serviceURL)
        {
            try
            {
                TransXTReqobject reqobject = new TransXTReqobject
                {
                    payload = request.getPaylaod(),
                    checksum = request.getChecksum()
                };
                string[] strArray = new string[] { "{\"payload\":", reqobject.payload, ",\"checksum\":\"", reqobject.checksum, "\"}" };
                string payload = string.Concat(strArray);
                Uri uri = new Uri(serviceURL, UriKind.Absolute);
                return ((uri.Scheme != "http") ? callSecuredService(uri, payload, request.getToken()) : callSecuredService(uri, payload, request.getToken()));
            }
            catch (Exception exception1)
            {
                ClsMethods.ResponseLogs(1, "callService", "MobileWare", serviceURL, request.getPaylaod(), exception1.Message, 0, "", "");
                return exception1.Message;
            }
        }

        public static string execute(string payload, string serviceUrl)
        {
            string message;
            try
            {
                TransXTReq request = new TransXTReq();
                if ((updatedToken == null) || (updatedToken.Length == 0))
                {
                    JObject obj2 = JObject.Parse(getAuthToken());
                    string str2 = (string)obj2.SelectToken("errorCode");
                    updatedToken = (string)obj2.SelectToken("token");
                    if (str2 != "0")
                    {
                        updatedToken = "";
                        return obj2.ToString();
                    }
                }
                string json = generateChecksum(payload, checksumURL, updatedToken);
                if (json == "The remote server returned an error: (401) Unauthorized.")
                {
                    updatedToken = "";
                    message = execute(payload, serviceUrl);
                }
                else
                {
                    JObject obj3 = JObject.Parse(json);
                    string str4 = (string)obj3.SelectToken("errorCode");
                    if (((str4 == "403") || ((str4 == "408") || (str4 == "E0008"))) || (str4 == "E0003"))
                    {
                        updatedToken = "";
                        message = execute(payload, serviceUrl);
                    }
                    else
                    {
                        request.setChecksum((string)obj3.SelectToken("response.checksum"));
                        request.setPaylaod(payload);
                        request.setToken(updatedToken);
                        string str5 = callService(request, serviceUrl);
                        JObject obj4 = JObject.Parse(str5);
                        string str6 = (string)obj4.SelectToken("token");
                        string str7 = (string)obj4.SelectToken("errorCode");
                        if (((str7 == "403") || ((str7 == "408") || (str4 == "E0008"))) || (str4 == "E0003"))
                        {
                            updatedToken = "";
                            message = execute(payload, serviceUrl);
                        }
                        else
                        {
                            if ((str6 != null) && (str6.Length > 0))
                            {
                                updatedToken = str6;
                            }
                            message = str5.ToString();
                        }
                    }
                }
            }
            catch (Exception exception1)
            {
                message = exception1.Message;
                ClsMethods.ResponseLogs(1, "execute", "MobileWare", serviceUrl, payload, message, 0, "", "");
            }
            return message;
        }

        private static string generateChecksum(string payload, string checksumURL, string updatedToken)
        {
            string message;
            try
            {
                string[] strArray = new string[] { "{\"payload\":", payload, ",\"checksum\":\"", updatedToken, "\"}" };
                string s = string.Concat(strArray);
                WebRequest request = WebRequest.Create(new Uri(checksumURL, UriKind.Absolute).AbsoluteUri);
                request.PreAuthenticate = true;
                request.Headers.Add("Authorization", "Bearer " + updatedToken);
                request.ContentType = "application/json";
                request.Method = "POST";
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                request.ContentLength = bytes.Length;
                //ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, (sender, certificate, chain, sslPolicyErrors) => true);
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, errors) => { return true; };
                Stream requestStream = request.GetRequestStream();
                using (requestStream = request.GetRequestStream())
                {
                    requestStream.Write(bytes, 0, bytes.Length);
                }
                WebResponse response = request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                if (responseStream == null)
                {
                    message = null;
                }
                else
                {
                    string json = new StreamReader(responseStream, Encoding.Default).ReadToEnd();
                    responseStream.Close();
                    response.Close();
                    message = JObject.Parse(json).ToString();
                }
            }
            catch (Exception exception1)
            {
                message = exception1.Message;
                ClsMethods.ResponseLogs(1, "generateChecksum", "MobileWare", checksumURL, payload + " | Token: " + updatedToken, message, 0, "", "");
            }
            return message;
        }

        private static string getAuthToken()
        {
            TransXTReq request = new TransXTReq();
            request.setPaylaod("{\"userName\":\"" + userName + "\",\"password\":\"" + password + "\"}");
            request.setChecksum("checksum");
            request.setToken(authToken);
            JObject obj2 = JObject.Parse(callService(request, authUrl));
            return ((((string)obj2.SelectToken("errorCode")) == "0") ? obj2.ToString() : obj2.ToString());
        }
    }
}
