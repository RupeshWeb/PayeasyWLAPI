﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace BusinessServices.TransXT
{
    public class ClsEncryption
    {
        public static byte[] keyStr = new byte[] { 0x42, 0x6a, 0x77, 0x6b, 70, 0x7a, 0x4f, 0x47, 0x6d, 0x38, 0x43, 0x31, 0x77, 0x6f, 0x79, 0x41 };
        public static byte[] ivArr = new byte[] { 0x22, 12, 0x38, 12, 5, 14, 0x25, 1, 0x37, 0x38, 3, 5, 0x4c, 6, 0x27, 0x1d };
        public static string combindedString = "";
        public static List<string> vals = new List<string>();

        public static string generateChecksum(string sortedJson, string secret) =>
            null;

        public static string getDecryptedText(string encryptedText)
        {
            try
            {
                RijndaelManaged managed = new RijndaelManaged
                {
                    BlockSize = 0x80,
                    KeySize = 0x100,
                    Mode = CipherMode.CBC,
                    Padding = PaddingMode.PKCS7,
                    Key = keyStr,
                    IV = ivArr
                };
                byte[] inputBuffer = Convert.FromBase64CharArray(encryptedText.ToCharArray(), 0, encryptedText.Length);
                byte[] bytes = managed.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length);
                return Encoding.UTF8.GetString(bytes);
            }
            catch (Exception exception1)
            {
                return exception1.Message;
            }
        }

        public static string getEncryptedText(string decryptedText)
        {
            try
            {
                RijndaelManaged managed = new RijndaelManaged
                {
                    BlockSize = 0x80,
                    KeySize = 0x100,
                    Mode = CipherMode.CBC,
                    Padding = PaddingMode.PKCS7,
                    Key = keyStr,
                    IV = ivArr
                };
                byte[] bytes = Encoding.UTF8.GetBytes(decryptedText);
                return Convert.ToBase64String(managed.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length));
            }
            catch (Exception exception1)
            {
                return exception1.Message;
            }
        }

        public static string getHashedJson(string payload, string secret)
        {
            try
            {
                getSorted(payload);
                return generateChecksum(payload, secret);
            }
            catch (Exception exception1)
            {
                return exception1.Message;
            }
        }

        private static string getSorted(string json)
        {
            try
            {
                JObject obj2 = JObject.Parse(json);
                if (obj2.Count > 0)
                {
                    foreach (KeyValuePair<string, JToken> pair in obj2)
                    {
                        string key = pair.Key;
                        JToken token = pair.Value;
                        if (key.Trim().Length > 0)
                        {
                            string item = token.ToString();
                            if (pair.Value.Count<JToken>() == 0)
                            {
                                vals.Add(item);
                            }
                            vals.Add(key);
                            getSorted(token.ToString());
                        }
                    }
                }
                vals = vals.OrderBy<string, string>(x => x, StringComparer.Ordinal).ToList<string>();
                combindedString = "[" + string.Join(", ", vals.ToArray()) + "]";
                string str3 = combindedString.Substring(3, combindedString.Length - 3);
                return ("[" + str3);
            }
            catch (Exception exception1)
            {
                return exception1.Message;
            }
        }
    }
}
